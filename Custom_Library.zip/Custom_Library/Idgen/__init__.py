from Idgen.idgen import generate_id

__all__ = ["generate_id"]