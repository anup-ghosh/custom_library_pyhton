import random
import string

def generate_id(length: int, uppercase: bool = True, lowercase: bool = True, numbers: bool = True, special: bool = False) -> str:
    """
    Generate a random ID with the specified length and character types.
    
    :param length: The length of the ID to generate
    :param uppercase: Include uppercase letters in the ID
    :param lowercase: Include lowercase letters in the ID
    :param numbers: Include numbers in the ID
    :param special: Include special characters in the ID
    :return: A random ID with the specified length and character types
    """
    # Define the character sets to use
    characters = ""
    if uppercase:
        characters += string.ascii_uppercase
    if lowercase:
        characters += string.ascii_lowercase
    if numbers:
        characters += string.digits
    if special:
        characters += string.punctuation

    # Generate the ID
    return "".join(random.choice(characters) for _ in range(length))
    

   