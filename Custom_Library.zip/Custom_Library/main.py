import Idgen

# Generate a random ID with all default options (length is required)
password = Idgen.generate_id(length=8,special=True,uppercase=True,lowercase=True,numbers=False)
print("Random ID:", password)